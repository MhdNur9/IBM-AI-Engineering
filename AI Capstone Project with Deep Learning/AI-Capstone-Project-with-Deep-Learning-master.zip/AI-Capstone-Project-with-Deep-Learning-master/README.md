# AI-Capstone-Project-with-Deep-Learning
https://www.coursera.org/learn/ai-deep-learning-capstone/home/welcome

### Data:

https://s3-api.us-geo.objectstorage.softlayer.net/cf-courses-data/CognitiveClass/DL0321EN/data/images/concrete_crack_images_for_classification.zip
